function pageLoad() {
	//$('#ctl00_PlaceHolderMain_actionBarBottom_divShowSaveandResume').insertBefore('#ctl00_PlaceHolderMain_actionBarBottom_btnContinue_container');

	$('.ACA_LiLeft').css('float', 'right');
	$('#ctl00_PlaceHolderMain_actionBarBottom_divShowSaveandResume').css('float', 'left');
	

}