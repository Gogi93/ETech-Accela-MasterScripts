function pageLoad() {
	$('.dsh-section-bottom').insertBefore('.dsh-mycollection');
	
	$('.dsh-section-bottom').css('padding','0');
}